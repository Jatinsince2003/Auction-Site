package com.jatinlogin.loginandregisterdemo.controller;


import com.jatinlogin.loginandregisterdemo.entity.ClosedItem;
import com.jatinlogin.loginandregisterdemo.entity.Item;
import com.jatinlogin.loginandregisterdemo.repostory.ClosedItemRepository;
import com.jatinlogin.loginandregisterdemo.repostory.ItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;
import java.util.Optional;

@Controller
public class ItemController {

    private final ItemRepository itemRepository;
    private final ClosedItemRepository closedItemRepository;

    @Autowired
    public ItemController(ItemRepository itemRepository, ClosedItemRepository closedItemRepository) {
        this.itemRepository = itemRepository;
        this.closedItemRepository = closedItemRepository;
    }

    @GetMapping("/add_items")
    public String showSignUpForm(Model model){
        model.addAttribute("item", new Item());
        return "items";
    }


    @GetMapping("/view_items")
    public String viewProducts(Model model){
        List<Item> itemList = itemRepository.findAll();
        model.addAttribute("itemList", itemList);
        return "show_items";
    }

    @GetMapping("/view_items_nl")
    public String viewProductsnl  (Model model){
        List<Item> itemList = itemRepository.findAll();
        model.addAttribute("itemList", itemList);
        return "show_items_nl";
    }

    @GetMapping("/closeditem")
    public String closeditems(Model model){
        List<ClosedItem> closedItemList = closedItemRepository.findAll();
        model.addAttribute("closedItemList", closedItemList);
        return "closed_item";
    }

    @RequestMapping("/deleteMyList/{id}")
    public String deleteMyList(@PathVariable("id") int id, Authentication authentication) {
        Optional<Item> optionalItem = itemRepository.findById(id);

        // Check if the item with the given id exists
        if (optionalItem.isPresent()) {
            Item item = optionalItem.get();

            String userEmail = authentication.getName();  // Get the authenticated user's email
            if (userEmail.equals(item.getEmail())) {
                itemRepository.deleteById(id);
                return "redirect:/view_items";
            } else {
                // User is not the owner, handle accordingly (e.g., show an error message)
                return "unauthorized_access";  // Create a template for unauthorized access
            }
        } else {
            // Handle case where the item with the given id doesn't exist
            return "item_not_found";  // Create a template for item not found
        }
    }


    @GetMapping("/editList/{id}")
    public String editList(@PathVariable("id") int id, Model model){

        Item item=itemRepository.getById(id);
        model.addAttribute("item", item);
        return "product_edit";

    }
    @PostMapping("/process_item")
    public String addItems(Item item, Authentication authentication) {
        String userEmail = authentication.getName();  // Get the authenticated user's email

        // Check if the item has an ID (existing item)
        if (item.getItem_id() != 0) {
            // Fetch the existing item from the repository
            Item existingItem = itemRepository.getById(item.getItem_id());

            // Check if the authenticated user is the owner of the item
            if (userEmail.equals(existingItem.getEmail())) {
                // Update the existing item
                existingItem.setImage_url(item.getImage_url());
                existingItem.setProduct_name(item.getProduct_name());
                existingItem.setInfo(item.getInfo());
                existingItem.setPrice(item.getPrice());
                itemRepository.save(existingItem);

                return "saved_success";
            } else {
                //user not authorized
                 return "unauthorized_access";
            }
        } else {
            // new item ke liye
            item.setEmail(userEmail);
            itemRepository.save(item);

            return "saved_success";
        }
    }

    @GetMapping("/product_info_detail/{id}")
    public String infos(@PathVariable int id, Model model) {
        // Assuming ItemRepository has a method to retrieve item details by id
        Optional<Item> optionalItem = itemRepository.findById(id);

        // Check if the item is present in the repository
        if (optionalItem.isPresent()) {
            // Add the item details to the model
            model.addAttribute("product", optionalItem.get());

            // Return the view name (product_info_detail.html)
            return "product_info_detail";
        } else {
            // Handle the case where the item with the given id is not found
            return "item_not_found";  // You can create an item_not_found.html page for this
        }
    }

    @GetMapping("/product_info_detail_nl/{id}")
    public String infoes(@PathVariable int id, Model model) {
        // Assuming ItemRepository has a method to retrieve item details by id
        Optional<Item> optionalItem = itemRepository.findById(id);

        // Check if the item is present in the repository
        if (optionalItem.isPresent()) {
            // Add the item details to the model
            model.addAttribute("product", optionalItem.get());

            // Return the view name (product_info_detail.html)
            return "product_info_detail_nl";
        } else {
            // Handle the case where the item with the given id is not found
            return "item_not_found";  // You can create an item_not_found.html page for this
        }
    }

    @PostMapping("/update_current_price")
    public String updateCurrentPrice(@RequestParam int itemId,
                                     @RequestParam double new_price,
                                     Authentication authentication) {

        // Retrieve the item from the repository
        Optional<Item> optionalItem = itemRepository.findById(itemId);

        // Check if the item is present
        if (optionalItem.isPresent()) {
            Item item = optionalItem.get();

            // Check if the new price is greater than the current price
            if (new_price > item.getPrice()) {
                // Update the item's price, email, and timestamp
                item.setPrice(new_price);
                item.setGambler(authentication.getName());
                // Set the timestamp (you may want to use a better approach for timestamp)
                item.setTimestamp(new Date());

                itemRepository.save(item);

                // Redirect back to the item details page
                return "redirect:/product_info_detail/" + itemId;
            } else {
                // Handle case where the new price is not greater
                return "price_not_greater";
            }
        } else {
            // Handle case where the item with the given id doesn't exist
            return "item_not_found";
        }
    }

    @GetMapping("/closeItem/{id}")
    public String closeItem(@PathVariable("id") int id, Authentication authentication) {
        Optional<Item> optionalItem = itemRepository.findById(id);

        // Check if the item with the given id exists
        if (optionalItem.isPresent()) {
            Item item = optionalItem.get();

            String userEmail = authentication.getName();  // Get the authenticated user's email
            if (userEmail.equals(item.getEmail())) {
                // Move the item to the closed_items table
                ClosedItem closedItem = new ClosedItem();
                closedItem.setEmail(item.getEmail());
                closedItem.setImage_url(item.getImage_url());
                closedItem.setInfo(item.getInfo());
                closedItem.setGambler(item.getGambler());
                closedItem.setPrice(item.getPrice());
                closedItem.setProduct_name(item.getProduct_name());

                closedItemRepository.save(closedItem);

                // Delete the item from the items table
                itemRepository.deleteById(id);

                return "redirect:/view_items";
            } else {
                // User is not the owner, handle accordingly (e.g., show an error message)
                return "unauthorized_access";  // Create a template for unauthorized access
            }
        } else {
            // Handle case where the item with the given id doesn't exist
            return "item_not_found";  // Create a template for item not found
        }
    }


    @GetMapping("/closed_item_info/{id}")
    public String closedItemInfo(@PathVariable int id, Model model) {
        Optional<ClosedItem> optionalClosedItem = closedItemRepository.findById(id);

        // Check if the closed item is present in the repository
        if (optionalClosedItem.isPresent()) {
            // Add the closed item details to the model
            model.addAttribute("closedItem", optionalClosedItem.get());

            // Return the view name (closed_item_info.html)
            return "closed_item_info";
        } else {
            // Handle the case where the closed item with the given id is not found
            return "closed_item_not_found";  // You can create a closed_item_not_found.html page for this
        }
    }
}


