package com.jatinlogin.loginandregisterdemo.controller;


import com.jatinlogin.loginandregisterdemo.entity.Comment;
import com.jatinlogin.loginandregisterdemo.repostory.CommentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;

@Controller
public class CommentController {

    private final CommentRepository commentRepository;

    @Autowired
    public CommentController(CommentRepository commentRepository) {
        this.commentRepository = commentRepository;
    }



    @PostMapping("/add")
    public String addComment(@RequestParam String message, Authentication authentication) {
        String userEmail = authentication.getName();
        Comment comment = new Comment();
        comment.setEmail(userEmail);
        comment.setComment(message);
        comment.setDateOfMessage(new Date());

        commentRepository.save(comment);
        return "comment_print";
    }

    @GetMapping("/allcomments")
    public String viewComments(Model model){
        List<Comment> commentList = commentRepository.findAll();
        model.addAttribute("commentList", commentList);
        return "all_comments";
    }


}
