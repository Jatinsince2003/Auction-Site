package com.jatinlogin.loginandregisterdemo.entity;

import jakarta.persistence.*;

import java.util.Date;


@Entity
@Table(name="msgs")
public class Comment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "comment_id")
    private int comment_id;
    @Column(name = "email")
    private String email;
    @Column(name = "comment", nullable = false)
    private String comment;

    @Column(name = "date_of_msg")
    private Date dateOfMessage;

    public Comment(){

    }

    public Comment(int comment_id, String email, String comment, Date dateOfMessage) {
        this.comment_id = comment_id;
        this.email = email;
        this.comment = comment;
        this.dateOfMessage = dateOfMessage;
    }

    public int getComment_id() {
        return comment_id;
    }

    public String getEmail() {
        return email;
    }

    public String getComment() {
        return comment;
    }

    public void setComment_id(int comment_id) {
        this.comment_id = comment_id;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public Date getDateOfMessage() {
        return dateOfMessage;
    }

    public void setDateOfMessage(Date dateOfMessage) {
        this.dateOfMessage = dateOfMessage;
    }
}
