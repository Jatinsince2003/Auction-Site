package com.jatinlogin.loginandregisterdemo.entity;


import jakarta.persistence.*;

@Entity
@Table(name = "closed_items")
public class ClosedItem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "item_id")
    private int item_id;

    @Column(name = "email")
    private String email;

    @Column(name = "image_url")
    private String image_url;

    @Column(name = "info")
    private String info;

    @Column(name = "price")
    private double price;

    @Column(name = "product_name")
    private String product_name;

    @Column(name = "gambler")
    private String gambler;

    public ClosedItem(int item_id, String email, String image_url, String info, double price, String product_name) {
        this.item_id = item_id;
        this.email = email;
        this.image_url = image_url;
        this.info = info;
        this.price = price;
        this.product_name = product_name;
    }

    public ClosedItem(int item_id, String email, String image_url, String info, double price, String product_name, String gambler) {
        this.item_id = item_id;
        this.email = email;
        this.image_url = image_url;
        this.info = info;
        this.price = price;
        this.product_name = product_name;
        this.gambler = gambler;
    }

    public ClosedItem() {

    }

    public int getItem_id() {
        return item_id;
    }

    public void setItem_id(int item_id) {
        this.item_id = item_id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getImage_url() {
        return image_url;
    }

    public void setImage_url(String image_url) {
        this.image_url = image_url;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getProduct_name() {
        return product_name;
    }

    public String getGambler() {
        return gambler;
    }

    public void setGambler(String gambler) {
        this.gambler = gambler;
    }

    public void setProduct_name(String product_name) {
        this.product_name = product_name;
    }
}
