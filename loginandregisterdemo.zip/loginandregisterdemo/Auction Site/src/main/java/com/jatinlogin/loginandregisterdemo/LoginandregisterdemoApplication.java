package com.jatinlogin.loginandregisterdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoginandregisterdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoginandregisterdemoApplication.class, args);
	}

}
