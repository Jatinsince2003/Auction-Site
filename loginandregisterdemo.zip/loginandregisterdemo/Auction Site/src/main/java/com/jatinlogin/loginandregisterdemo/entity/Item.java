package com.jatinlogin.loginandregisterdemo.entity;


import jakarta.persistence.*;

import java.util.Date;
import java.util.Objects;

@Entity
@Table(name = "products")
public class Item {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "item_id")
    private int item_id;

    @Column(name = "email")
    private String email;

    @Column(name = "image_url")
    private String image_url;
    @Column(name = "info")
    private String info;

    @Column(name = "price")
    private double price;

    @Column(name = "product_name")
    private String product_name;

    @Column(name = "gambler")
    private String gambler;


    public Item(){

    }


    public Item(int item_id, String email, String image_url, String info, double price, String product_name, double new_price) {
        this.item_id = item_id;
        this.email = email;
        this.image_url = image_url;
        this.info = info;
        this.price = price;
        this.product_name = product_name;
    }

    public Item(int item_id, String email, String image_url, String info, double price, String product_name, String gambler) {
        this.item_id = item_id;
        this.email = email;
        this.image_url = image_url;
        this.info = info;
        this.price = price;
        this.product_name = product_name;
        this.gambler = gambler;
    }

    public int getItem_id() {
        return item_id;
    }

    public void setItem_id(int item_id) {
        this.item_id = item_id;
    }

    public String getImage_url() {
        return image_url;
    }

    public void setImage_url(String image_url) {
        this.image_url = image_url;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Item item = (Item) o;
        return Objects.equals(getItem_id(), item.getItem_id());
    }

    public String getGambler() {
        return gambler;
    }

    public void setGambler(String gambler) {
        this.gambler = gambler;
    }

    public String getProduct_name() {
        return product_name;
    }



    public void setProduct_name(String product_name) {
        this.product_name = product_name;
    }

    @Override
    public int hashCode() {
        return Objects.hash(getItem_id());
    }

    public void setTimestamp(Date date) {
    }

}
