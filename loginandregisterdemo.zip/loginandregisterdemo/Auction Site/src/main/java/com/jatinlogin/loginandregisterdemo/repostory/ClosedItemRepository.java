package com.jatinlogin.loginandregisterdemo.repostory;

import com.jatinlogin.loginandregisterdemo.entity.ClosedItem;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ClosedItemRepository extends JpaRepository <ClosedItem, Integer> {
}
